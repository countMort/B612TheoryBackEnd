const JSZip     = require('jszip'),
    { download }    = require('../../utils/fs')
module.exports = function(polaroids) {
    return new Promise((resolve, reject) => {
        let zip = new JSZip()
    })
}